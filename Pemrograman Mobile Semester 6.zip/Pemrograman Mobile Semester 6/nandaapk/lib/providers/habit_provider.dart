import 'package:flutter/foundation.dart';
import 'dart:developer' as developer;
import '../models/habit.dart';
import '../models/habit_progress.dart';
import '../services/database_service.dart';

class HabitProvider with ChangeNotifier {
  final DatabaseService _databaseService = DatabaseService();
  List<Habit> _habits = [];
  Map<int, List<HabitProgress>> _progressMap = {};
  Map<int, int> _currentStreaks = {};
  Map<int, int> _longestStreaks = {};

  List<Habit> get habits => _habits;
  Map<int, List<HabitProgress>> get progressMap => _progressMap;
  Map<int, int> get currentStreaks => _currentStreaks;
  Map<int, int> get longestStreaks => _longestStreaks;

  Future<void> loadHabits() async {
    developer.log('Loading habits...');
    _habits = await _databaseService.getHabits();
    developer.log('Loaded ${_habits.length} habits');
    for (var habit in _habits) {
      await loadHabitProgress(habit.id!);
      await loadStreaks(habit.id!);
    }
    notifyListeners();
  }

  Future<void> loadHabitProgress(int habitId) async {
    developer.log('Loading progress for habit id: $habitId');
    _progressMap[habitId] = await _databaseService.getHabitProgress(habitId);
    developer.log('Loaded ${_progressMap[habitId]?.length ?? 0} progress records');
    notifyListeners();
  }

  Future<void> loadStreaks(int habitId) async {
    developer.log('Loading streaks for habit id: $habitId');
    _currentStreaks[habitId] = await _databaseService.getCurrentStreak(habitId);
    _longestStreaks[habitId] = await _databaseService.getLongestStreak(habitId);
    developer.log('Current streak: ${_currentStreaks[habitId]}, Longest streak: ${_longestStreaks[habitId]}');
    notifyListeners();
  }

  Future<void> addHabit(Habit habit) async {
    developer.log('Adding new habit: ${habit.toMap()}');
    final id = await _databaseService.insertHabit(habit);
    developer.log('Habit added with id: $id');
    final newHabit = habit.copyWith(id: id);
    _habits.add(newHabit);
    _progressMap[id] = [];
    _currentStreaks[id] = 0;
    _longestStreaks[id] = 0;
    notifyListeners();
  }

  Future<void> updateHabit(Habit habit) async {
    developer.log('Updating habit: ${habit.toMap()}');
    await _databaseService.updateHabit(habit);
    final index = _habits.indexWhere((h) => h.id == habit.id);
    if (index != -1) {
      _habits[index] = habit;
      developer.log('Habit updated successfully');
      notifyListeners();
    } else {
      developer.log('Habit not found for update');
    }
  }

  Future<void> deleteHabit(int id) async {
    developer.log('Deleting habit with id: $id');
    await _databaseService.deleteHabit(id);
    _habits.removeWhere((h) => h.id == id);
    _progressMap.remove(id);
    _currentStreaks.remove(id);
    _longestStreaks.remove(id);
    developer.log('Habit deleted successfully');
    notifyListeners();
  }

  Future<void> toggleHabitProgress(int habitId, DateTime date) async {
    developer.log('Toggling progress for habit id: $habitId on date: $date');
    final progress = await _databaseService.getHabitProgressByDate(habitId, date);
    final now = DateTime.now();

    if (progress == null) {
      developer.log('No existing progress, creating new progress record');
      final newProgress = HabitProgress(
        habitId: habitId,
        date: date,
        isCompleted: true,
        createdAt: now,
        updatedAt: now,
      );
      final id = await _databaseService.insertHabitProgress(newProgress);
      _progressMap[habitId]?.add(newProgress.copyWith(id: id));
      developer.log('New progress record created with id: $id');
    } else {
      developer.log('Updating existing progress record');
      final updatedProgress = progress.copyWith(
        isCompleted: !progress.isCompleted,
        updatedAt: now,
      );
      await _databaseService.updateHabitProgress(updatedProgress);
      final index = _progressMap[habitId]?.indexWhere((p) => p.id == progress.id) ?? -1;
      if (index != -1) {
        _progressMap[habitId]?[index] = updatedProgress;
        developer.log('Progress record updated successfully');
      } else {
        developer.log('Progress record not found in memory');
      }
    }

    await loadStreaks(habitId);
    notifyListeners();
  }
} 