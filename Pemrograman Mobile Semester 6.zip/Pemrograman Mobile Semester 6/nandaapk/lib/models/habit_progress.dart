import 'dart:developer' as developer;

class HabitProgress {
  final int? id;
  final int habitId;
  final DateTime date;
  final bool isCompleted;
  final DateTime createdAt;
  final DateTime updatedAt;

  HabitProgress({
    this.id,
    required this.habitId,
    required this.date,
    required this.isCompleted,
    required this.createdAt,
    required this.updatedAt,
  }) {
    developer.log('Created HabitProgress instance: ${toMap()}');
  }

  Map<String, dynamic> toMap() {
    final map = {
      'id': id,
      'habit_id': habitId,
      'date': date.toIso8601String(),
      'is_completed': isCompleted ? 1 : 0,
      'created_at': createdAt.toIso8601String(),
      'updated_at': updatedAt.toIso8601String(),
    };
    developer.log('Converting HabitProgress to map: $map');
    return map;
  }

  factory HabitProgress.fromMap(Map<String, dynamic> map) {
    developer.log('Creating HabitProgress from map: $map');
    return HabitProgress(
      id: map['id'],
      habitId: map['habit_id'],
      date: DateTime.parse(map['date']),
      isCompleted: map['is_completed'] == 1,
      createdAt: DateTime.parse(map['created_at']),
      updatedAt: DateTime.parse(map['updated_at']),
    );
  }

  HabitProgress copyWith({
    int? id,
    int? habitId,
    DateTime? date,
    bool? isCompleted,
    DateTime? createdAt,
    DateTime? updatedAt,
  }) {
    developer.log('Creating copy of HabitProgress with changes: id=$id, habitId=$habitId, date=$date, isCompleted=$isCompleted, createdAt=$createdAt, updatedAt=$updatedAt');
    return HabitProgress(
      id: id ?? this.id,
      habitId: habitId ?? this.habitId,
      date: date ?? this.date,
      isCompleted: isCompleted ?? this.isCompleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
} 