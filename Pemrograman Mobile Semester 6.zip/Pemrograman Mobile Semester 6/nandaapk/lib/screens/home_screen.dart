import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:developer' as developer;
import '../providers/habit_provider.dart';
import '../models/habit.dart';
import 'habit_detail_screen.dart';
import 'add_habit_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  @override
  void initState() {
    super.initState();
    developer.log('HomeScreen initialized');
    // Memuat data kebiasaan saat halaman pertama kali dibuka
    Future.microtask(() {
      developer.log('Loading habits in initState');
      context.read<HabitProvider>().loadHabits();
    });
  }

  @override
  Widget build(BuildContext context) {
    developer.log('Building HomeScreen');
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Habit Streaks'),
        centerTitle: true,
      ),
      body: Consumer<HabitProvider>(
        builder: (context, habitProvider, child) {
          final habits = habitProvider.habits;
          developer.log('Building with ${habits.length} habits');
          
          if (habits.isEmpty) {
            developer.log('No habits found, showing empty state');
            return const Center(
              child: Text(
                'Belum ada kebiasaan yang ditambahkan.\nTambahkan kebiasaan baru untuk memulai!',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 16),
              ),
            );
          }

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: habits.length,
            itemBuilder: (context, index) {
              final habit = habits[index];
              final currentStreak = habitProvider.currentStreaks[habit.id] ?? 0;
              developer.log('Building habit card for: ${habit.name} with streak: $currentStreak');
              
              return Card(
                margin: const EdgeInsets.only(bottom: 16),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: habit.color != null 
                        ? Color(int.parse(habit.color!))
                        : Theme.of(context).primaryColor,
                    child: Text(
                      habit.name[0].toUpperCase(),
                      style: const TextStyle(color: Colors.white),
                    ),
                  ),
                  title: Text(habit.name),
                  subtitle: Text(
                    'Streak saat ini: $currentStreak hari',
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  trailing: IconButton(
                    icon: const Icon(Icons.arrow_forward_ios),
                    onPressed: () {
                      developer.log('Navigating to detail screen for habit: ${habit.name}');
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => HabitDetailScreen(habit: habit),
                        ),
                      );
                    },
                  ),
                  onTap: () {
                    developer.log('Navigating to detail screen for habit: ${habit.name}');
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HabitDetailScreen(habit: habit),
                      ),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          developer.log('Opening AddHabitScreen');
          await Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const AddHabitScreen(),
            ),
          );
          // Memuat ulang data setelah menambah kebiasaan baru
          if (mounted) {
            developer.log('Reloading habits after returning from AddHabitScreen');
            context.read<HabitProvider>().loadHabits();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
} 