import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:table_calendar/table_calendar.dart';
import 'dart:developer' as developer;
import '../models/habit.dart';
import '../providers/habit_provider.dart';

class HabitDetailScreen extends StatefulWidget {
  final Habit habit;

  const HabitDetailScreen({super.key, required this.habit});

  @override
  State<HabitDetailScreen> createState() => _HabitDetailScreenState();
}

class _HabitDetailScreenState extends State<HabitDetailScreen> {
  late DateTime _focusedDay;
  late DateTime _selectedDay;
  late CalendarFormat _calendarFormat;

  @override
  void initState() {
    super.initState();
    developer.log('HabitDetailScreen initialized for habit: ${widget.habit.name}');
    _focusedDay = DateTime.now();
    _selectedDay = _focusedDay;
    _calendarFormat = CalendarFormat.month;
  }

  @override
  Widget build(BuildContext context) {
    developer.log('Building HabitDetailScreen for habit: ${widget.habit.name}');
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.habit.name),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              developer.log('Edit button pressed for habit: ${widget.habit.name}');
              // TODO: Implement edit habit
            },
          ),
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: () {
              developer.log('Delete button pressed for habit: ${widget.habit.name}');
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text('Hapus Kebiasaan'),
                  content: Text(
                    'Apakah Anda yakin ingin menghapus kebiasaan "${widget.habit.name}"?',
                  ),
                  actions: [
                    TextButton(
                      onPressed: () {
                        developer.log('Delete cancelled for habit: ${widget.habit.name}');
                        Navigator.pop(context);
                      },
                      child: const Text('Batal'),
                    ),
                    TextButton(
                      onPressed: () {
                        developer.log('Deleting habit: ${widget.habit.name}');
                        context.read<HabitProvider>().deleteHabit(widget.habit.id!);
                        Navigator.pop(context); // Close dialog
                        Navigator.pop(context); // Return to home screen
                      },
                      child: const Text(
                        'Hapus',
                        style: TextStyle(color: Colors.red),
                      ),
                    ),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: Consumer<HabitProvider>(
        builder: (context, habitProvider, child) {
          final currentStreak = habitProvider.currentStreaks[widget.habit.id] ?? 0;
          final longestStreak = habitProvider.longestStreaks[widget.habit.id] ?? 0;
          final progress = habitProvider.progressMap[widget.habit.id] ?? [];
          developer.log('Building detail view with current streak: $currentStreak, longest streak: $longestStreak, progress count: ${progress.length}');

          return SingleChildScrollView(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (widget.habit.description != null) ...[
                  Text(
                    widget.habit.description!,
                    style: Theme.of(context).textTheme.bodyLarge,
                  ),
                  const SizedBox(height: 24),
                ],
                Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _buildStatCard(
                          context,
                          'Streak Saat Ini',
                          currentStreak.toString(),
                          'hari',
                        ),
                        _buildStatCard(
                          context,
                          'Streak Terpanjang',
                          longestStreak.toString(),
                          'hari',
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                TableCalendar(
                  firstDay: DateTime.utc(2024, 1, 1),
                  lastDay: DateTime.utc(2025, 12, 31),
                  focusedDay: _focusedDay,
                  calendarFormat: _calendarFormat,
                  selectedDayPredicate: (day) {
                    return isSameDay(_selectedDay, day);
                  },
                  onDaySelected: (selectedDay, focusedDay) {
                    developer.log('Day selected: $selectedDay');
                    setState(() {
                      _selectedDay = selectedDay;
                      _focusedDay = focusedDay;
                    });
                    habitProvider.toggleHabitProgress(widget.habit.id!, selectedDay);
                  },
                  calendarStyle: CalendarStyle(
                    markersMaxCount: 1,
                    markerDecoration: BoxDecoration(
                      color: Theme.of(context).primaryColor,
                      shape: BoxShape.circle,
                    ),
                  ),
                  calendarBuilders: CalendarBuilders(
                    markerBuilder: (context, date, events) {
                      final isCompleted = progress.any(
                        (p) => p.date.year == date.year &&
                               p.date.month == date.month &&
                               p.date.day == date.day &&
                               p.isCompleted,
                      );
                      if (isCompleted) {
                        developer.log('Found completed progress for date: $date');
                        return Container(
                          margin: const EdgeInsets.all(1),
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            color: Theme.of(context).primaryColor,
                          ),
                        );
                      }
                      return null;
                    },
                  ),
                  onFormatChanged: (format) {
                    developer.log('Calendar format changed to: $format');
                    setState(() {
                      _calendarFormat = format;
                    });
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatCard(
    BuildContext context,
    String title,
    String value,
    String unit,
  ) {
    return Column(
      children: [
        Text(
          title,
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 8),
        Text(
          value,
          style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                color: Theme.of(context).primaryColor,
                fontWeight: FontWeight.bold,
              ),
        ),
        Text(
          unit,
          style: Theme.of(context).textTheme.bodySmall,
        ),
      ],
    );
  }
} 