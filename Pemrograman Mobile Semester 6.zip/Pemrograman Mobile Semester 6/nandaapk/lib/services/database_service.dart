import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'dart:developer' as developer;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';
import 'package:flutter/foundation.dart';
import '../models/habit.dart';
import '../models/habit_progress.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  static Database? _database;

  factory DatabaseService() => _instance;

  DatabaseService._internal() {
    if (kIsWeb) {
      // Initialize FFI for web
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }
  }

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    String path = join(await getDatabasesPath(), 'habit_streaks.db');
    developer.log('Initializing database at: $path');
    return await openDatabase(
      path,
      version: 1,
      onCreate: _createDb,
    );
  }

  Future<void> _createDb(Database db, int version) async {
    developer.log('Creating database tables...');
    await db.execute('''
      CREATE TABLE habits(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        description TEXT,
        icon TEXT,
        color TEXT,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
      )
    ''');

    await db.execute('''
      CREATE TABLE habit_progress(
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        habit_id INTEGER NOT NULL,
        date TEXT NOT NULL,
        is_completed INTEGER NOT NULL,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL,
        FOREIGN KEY (habit_id) REFERENCES habits (id) ON DELETE CASCADE
      )
    ''');
    developer.log('Database tables created successfully');
  }

  // Habit CRUD operations
  Future<int> insertHabit(Habit habit) async {
    final db = await database;
    developer.log('Inserting habit: ${habit.toMap()}');
    final id = await db.insert('habits', habit.toMap());
    developer.log('Habit inserted with id: $id');
    return id;
  }

  Future<List<Habit>> getHabits() async {
    final db = await database;
    developer.log('Getting all habits...');
    final List<Map<String, dynamic>> maps = await db.query('habits');
    final habits = List.generate(maps.length, (i) => Habit.fromMap(maps[i]));
    developer.log('Found ${habits.length} habits');
    return habits;
  }

  Future<Habit?> getHabit(int id) async {
    final db = await database;
    developer.log('Getting habit with id: $id');
    final List<Map<String, dynamic>> maps = await db.query(
      'habits',
      where: 'id = ?',
      whereArgs: [id],
    );
    if (maps.isEmpty) {
      developer.log('No habit found with id: $id');
      return null;
    }
    developer.log('Found habit: ${maps.first}');
    return Habit.fromMap(maps.first);
  }

  Future<int> updateHabit(Habit habit) async {
    final db = await database;
    developer.log('Updating habit: ${habit.toMap()}');
    final result = await db.update(
      'habits',
      habit.toMap(),
      where: 'id = ?',
      whereArgs: [habit.id],
    );
    developer.log('Updated $result rows');
    return result;
  }

  Future<int> deleteHabit(int id) async {
    final db = await database;
    developer.log('Deleting habit with id: $id');
    final result = await db.delete(
      'habits',
      where: 'id = ?',
      whereArgs: [id],
    );
    developer.log('Deleted $result rows');
    return result;
  }

  // HabitProgress CRUD operations
  Future<int> insertHabitProgress(HabitProgress progress) async {
    final db = await database;
    developer.log('Inserting habit progress: ${progress.toMap()}');
    final id = await db.insert('habit_progress', progress.toMap());
    developer.log('Habit progress inserted with id: $id');
    return id;
  }

  Future<List<HabitProgress>> getHabitProgress(int habitId) async {
    final db = await database;
    developer.log('Getting progress for habit id: $habitId');
    final List<Map<String, dynamic>> maps = await db.query(
      'habit_progress',
      where: 'habit_id = ?',
      whereArgs: [habitId],
    );
    final progress = List.generate(maps.length, (i) => HabitProgress.fromMap(maps[i]));
    developer.log('Found ${progress.length} progress records');
    return progress;
  }

  Future<HabitProgress?> getHabitProgressByDate(int habitId, DateTime date) async {
    final db = await database;
    developer.log('Getting progress for habit id: $habitId on date: $date');
    final List<Map<String, dynamic>> maps = await db.query(
      'habit_progress',
      where: 'habit_id = ? AND date = ?',
      whereArgs: [habitId, date.toIso8601String()],
    );
    if (maps.isEmpty) {
      developer.log('No progress found for the specified date');
      return null;
    }
    developer.log('Found progress: ${maps.first}');
    return HabitProgress.fromMap(maps.first);
  }

  Future<int> updateHabitProgress(HabitProgress progress) async {
    final db = await database;
    developer.log('Updating habit progress: ${progress.toMap()}');
    final result = await db.update(
      'habit_progress',
      progress.toMap(),
      where: 'id = ?',
      whereArgs: [progress.id],
    );
    developer.log('Updated $result rows');
    return result;
  }

  Future<int> deleteHabitProgress(int id) async {
    final db = await database;
    developer.log('Deleting habit progress with id: $id');
    final result = await db.delete(
      'habit_progress',
      where: 'id = ?',
      whereArgs: [id],
    );
    developer.log('Deleted $result rows');
    return result;
  }

  // Streak calculation
  Future<int> getCurrentStreak(int habitId) async {
    final db = await database;
    final today = DateTime.now();
    developer.log('Calculating current streak for habit id: $habitId');
    final progress = await getHabitProgress(habitId);
    
    if (progress.isEmpty) {
      developer.log('No progress found, returning 0');
      return 0;
    }

    int streak = 0;
    DateTime currentDate = today;

    while (true) {
      final dayProgress = progress.firstWhere(
        (p) => p.date.year == currentDate.year &&
               p.date.month == currentDate.month &&
               p.date.day == currentDate.day,
        orElse: () => HabitProgress(
          habitId: habitId,
          date: currentDate,
          isCompleted: false,
          createdAt: DateTime.now(),
          updatedAt: DateTime.now(),
        ),
      );

      if (!dayProgress.isCompleted) break;
      streak++;
      currentDate = currentDate.subtract(const Duration(days: 1));
    }

    developer.log('Current streak: $streak');
    return streak;
  }

  Future<int> getLongestStreak(int habitId) async {
    final db = await database;
    developer.log('Calculating longest streak for habit id: $habitId');
    final progress = await getHabitProgress(habitId);
    
    if (progress.isEmpty) {
      developer.log('No progress found, returning 0');
      return 0;
    }

    int currentStreak = 0;
    int longestStreak = 0;
    DateTime? lastDate;

    for (var p in progress.where((p) => p.isCompleted).toList()
      ..sort((a, b) => a.date.compareTo(b.date))) {
      if (lastDate == null) {
        currentStreak = 1;
      } else {
        final difference = p.date.difference(lastDate).inDays;
        if (difference == 1) {
          currentStreak++;
        } else {
          currentStreak = 1;
        }
      }
      longestStreak = currentStreak > longestStreak ? currentStreak : longestStreak;
      lastDate = p.date;
    }

    developer.log('Longest streak: $longestStreak');
    return longestStreak;
  }
} 