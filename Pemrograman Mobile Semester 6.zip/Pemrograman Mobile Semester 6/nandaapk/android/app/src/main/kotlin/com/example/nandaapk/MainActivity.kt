package com.example.nandaapk

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
